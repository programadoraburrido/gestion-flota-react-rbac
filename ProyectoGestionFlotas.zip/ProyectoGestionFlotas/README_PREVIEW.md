Preview instructions

This creates a lightweight mock preview of the app (no Firebase). It mounts `components/PreviewApp.js` which uses the UI components with mocked data.

How to open locally

You must serve the folder over HTTP (file:// won't work reliably). Two quick options are shown; run one in a terminal from the `ProyectoGestionFlotas` folder.

Python (built-in):

```bash
# macOS / Linux
python3 -m http.server 5173
# open http://localhost:5173 in your browser
```

Node (if you have npx):

```bash
npx serve . -l 5173
# open http://localhost:5173
```

What you'll see

- A small preview SPA using mocked vehicles.
- Theme toggle and "Añadir" button (the Add form uses a local "onAdd" and won't save to Firebase).
 - Theme toggle and "Añadir" button (the Add form uses a local "onAdd" and won't save to Firebase).
 - Mapa en tiempo real: abre la vista "Mapa" para ver las posiciones (simuladas) de los vehículos y observar cómo se actualizan cada pocos segundos.

Notes

- This is a preview harness only; it intentionally avoids Firebase initialization so you can inspect UI and flows without credentials.
 - This is a preview harness only; it intentionally avoids Firebase initialization so you can inspect UI and flows without credentials. The realtime map uses Leaflet from a CDN; if your environment blocks CDN ESM imports, the map will show an error placeholder.
- When you're ready to test the real app (with Firebase), run the real entry `appCoche.js` in a proper dev setup and provide your Firebase config (see `models/useFirebaseApp.js`).
